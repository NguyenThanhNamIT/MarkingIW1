# Generated from IELTSWriting.g4 by ANTLR 4.9.2
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
    from typing import TextIO
else:
    from typing.io import TextIO



def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\17")
        buf.write("\u0114\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\3\2\3\2\3\2\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write("\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\5\4J\n\4\3\5\3\5\3\5\3\5\3\5")
        buf.write("\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3")
        buf.write("\5\3\5\3\5\3\5\3\5\5\5c\n\5\3\6\3\6\3\6\3\6\3\6\3\6\3")
        buf.write("\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6")
        buf.write("\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\3")
        buf.write("\6\3\6\3\6\3\6\3\6\3\6\3\6\3\6\5\6\u008e\n\6\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write("\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write("\3\7\3\7\5\7\u00bd\n\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b")
        buf.write("\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3")
        buf.write("\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b")
        buf.write("\3\b\3\b\3\b\3\b\5\b\u00e6\n\b\3\t\6\t\u00e9\n\t\r\t\16")
        buf.write("\t\u00ea\3\n\6\n\u00ee\n\n\r\n\16\n\u00ef\3\13\3\13\3")
        buf.write("\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13\3\13")
        buf.write("\3\13\3\13\3\13\3\13\3\13\3\13\5\13\u0105\n\13\3\f\3\f")
        buf.write("\3\r\6\r\u010a\n\r\r\r\16\r\u010b\3\16\6\16\u010f\n\16")
        buf.write("\r\16\16\16\u0110\3\16\3\16\2\2\17\3\3\5\4\7\5\t\6\13")
        buf.write("\7\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\3\2\6\3\2")
        buf.write("\62;\5\2%%..\60\60\4\2C\\c|\5\2\13\f\17\17\"\"\2\u012b")
        buf.write("\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13")
        buf.write("\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3")
        buf.write("\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33\3\2")
        buf.write("\2\2\3\35\3\2\2\2\5 \3\2\2\2\7I\3\2\2\2\tb\3\2\2\2\13")
        buf.write("\u008d\3\2\2\2\r\u00bc\3\2\2\2\17\u00e5\3\2\2\2\21\u00e8")
        buf.write("\3\2\2\2\23\u00ed\3\2\2\2\25\u0104\3\2\2\2\27\u0106\3")
        buf.write("\2\2\2\31\u0109\3\2\2\2\33\u010e\3\2\2\2\35\36\7k\2\2")
        buf.write("\36\37\7p\2\2\37\4\3\2\2\2 !\7Q\2\2!\"\7x\2\2\"#\7g\2")
        buf.write("\2#$\7t\2\2$%\7c\2\2%&\7n\2\2&\'\7n\2\2\'\6\3\2\2\2()")
        buf.write("\7u\2\2)*\7c\2\2*+\7n\2\2+,\7g\2\2,J\7u\2\2-.\7r\2\2.")
        buf.write("/\7t\2\2/\60\7k\2\2\60\61\7e\2\2\61J\7g\2\2\62\63\7W\2")
        buf.write("\2\63\64\7p\2\2\64\65\7k\2\2\65\66\7v\2\2\66\67\7g\2\2")
        buf.write("\678\7f\2\289\7\"\2\29:\7U\2\2:;\7v\2\2;<\7c\2\2<=\7v")
        buf.write("\2\2=>\7g\2\2>J\7u\2\2?@\7E\2\2@A\7j\2\2AB\7k\2\2BC\7")
        buf.write("p\2\2CJ\7c\2\2DE\7L\2\2EF\7c\2\2FG\7r\2\2GH\7c\2\2HJ\7")
        buf.write("p\2\2I(\3\2\2\2I-\3\2\2\2I\62\3\2\2\2I?\3\2\2\2ID\3\2")
        buf.write("\2\2J\b\3\2\2\2KL\7E\2\2LM\7j\2\2MN\7k\2\2NO\7p\2\2OP")
        buf.write("\7g\2\2PQ\7u\2\2Qc\7g\2\2RS\7L\2\2ST\7c\2\2TU\7r\2\2U")
        buf.write("V\7c\2\2VW\7p\2\2WX\7g\2\2XY\7u\2\2Yc\7g\2\2Z[\7C\2\2")
        buf.write("[\\\7o\2\2\\]\7g\2\2]^\7t\2\2^_\7k\2\2_`\7e\2\2`a\7c\2")
        buf.write("\2ac\7p\2\2bK\3\2\2\2bR\3\2\2\2bZ\3\2\2\2c\n\3\2\2\2d")
        buf.write("e\7k\2\2ef\7p\2\2fg\7e\2\2gh\7t\2\2hi\7g\2\2ij\7c\2\2")
        buf.write("jk\7u\2\2kl\7g\2\2l\u008e\7f\2\2mn\7f\2\2no\7g\2\2op\7")
        buf.write("e\2\2pq\7t\2\2qr\7g\2\2rs\7c\2\2st\7u\2\2tu\7g\2\2u\u008e")
        buf.write("\7f\2\2vw\7t\2\2wx\7q\2\2xy\7u\2\2y\u008e\7g\2\2z{\7h")
        buf.write("\2\2{|\7g\2\2|}\7n\2\2}\u008e\7n\2\2~\177\7t\2\2\177\u0080")
        buf.write("\7g\2\2\u0080\u0081\7o\2\2\u0081\u0082\7c\2\2\u0082\u0083")
        buf.write("\7k\2\2\u0083\u0084\7p\2\2\u0084\u0085\7g\2\2\u0085\u008e")
        buf.write("\7f\2\2\u0086\u0087\7t\2\2\u0087\u0088\7g\2\2\u0088\u0089")
        buf.write("\7c\2\2\u0089\u008a\7e\2\2\u008a\u008b\7j\2\2\u008b\u008c")
        buf.write("\7g\2\2\u008c\u008e\7f\2\2\u008dd\3\2\2\2\u008dm\3\2\2")
        buf.write("\2\u008dv\3\2\2\2\u008dz\3\2\2\2\u008d~\3\2\2\2\u008d")
        buf.write("\u0086\3\2\2\2\u008e\f\3\2\2\2\u008f\u0090\7u\2\2\u0090")
        buf.write("\u0091\7j\2\2\u0091\u0092\7c\2\2\u0092\u0093\7t\2\2\u0093")
        buf.write("\u0094\7r\2\2\u0094\u0095\7n\2\2\u0095\u00bd\7{\2\2\u0096")
        buf.write("\u0097\7i\2\2\u0097\u0098\7t\2\2\u0098\u0099\7c\2\2\u0099")
        buf.write("\u009a\7f\2\2\u009a\u009b\7w\2\2\u009b\u009c\7c\2\2\u009c")
        buf.write("\u009d\7n\2\2\u009d\u009e\7n\2\2\u009e\u00bd\7{\2\2\u009f")
        buf.write("\u00a0\7u\2\2\u00a0\u00a1\7v\2\2\u00a1\u00a2\7g\2\2\u00a2")
        buf.write("\u00a3\7c\2\2\u00a3\u00a4\7f\2\2\u00a4\u00a5\7k\2\2\u00a5")
        buf.write("\u00a6\7n\2\2\u00a6\u00bd\7{\2\2\u00a7\u00a8\7u\2\2\u00a8")
        buf.write("\u00a9\7n\2\2\u00a9\u00aa\7k\2\2\u00aa\u00ab\7i\2\2\u00ab")
        buf.write("\u00ac\7j\2\2\u00ac\u00ad\7v\2\2\u00ad\u00ae\7n\2\2\u00ae")
        buf.write("\u00bd\7{\2\2\u00af\u00b0\7u\2\2\u00b0\u00b1\7k\2\2\u00b1")
        buf.write("\u00b2\7i\2\2\u00b2\u00b3\7p\2\2\u00b3\u00b4\7k\2\2\u00b4")
        buf.write("\u00b5\7h\2\2\u00b5\u00b6\7k\2\2\u00b6\u00b7\7e\2\2\u00b7")
        buf.write("\u00b8\7c\2\2\u00b8\u00b9\7p\2\2\u00b9\u00ba\7v\2\2\u00ba")
        buf.write("\u00bb\7n\2\2\u00bb\u00bd\7{\2\2\u00bc\u008f\3\2\2\2\u00bc")
        buf.write("\u0096\3\2\2\2\u00bc\u009f\3\2\2\2\u00bc\u00a7\3\2\2\2")
        buf.write("\u00bc\u00af\3\2\2\2\u00bd\16\3\2\2\2\u00be\u00bf\7j\2")
        buf.write("\2\u00bf\u00c0\7k\2\2\u00c0\u00c1\7i\2\2\u00c1\u00c2\7")
        buf.write("j\2\2\u00c2\u00c3\7g\2\2\u00c3\u00c4\7t\2\2\u00c4\u00c5")
        buf.write("\7\"\2\2\u00c5\u00c6\7v\2\2\u00c6\u00c7\7j\2\2\u00c7\u00c8")
        buf.write("\7c\2\2\u00c8\u00e6\7p\2\2\u00c9\u00ca\7n\2\2\u00ca\u00cb")
        buf.write("\7q\2\2\u00cb\u00cc\7y\2\2\u00cc\u00cd\7g\2\2\u00cd\u00ce")
        buf.write("\7t\2\2\u00ce\u00cf\7\"\2\2\u00cf\u00d0\7v\2\2\u00d0\u00d1")
        buf.write("\7j\2\2\u00d1\u00d2\7c\2\2\u00d2\u00e6\7p\2\2\u00d3\u00d4")
        buf.write("\7g\2\2\u00d4\u00d5\7s\2\2\u00d5\u00d6\7w\2\2\u00d6\u00d7")
        buf.write("\7c\2\2\u00d7\u00d8\7n\2\2\u00d8\u00d9\7\"\2\2\u00d9\u00da")
        buf.write("\7v\2\2\u00da\u00e6\7q\2\2\u00db\u00dc\7u\2\2\u00dc\u00dd")
        buf.write("\7k\2\2\u00dd\u00de\7o\2\2\u00de\u00df\7k\2\2\u00df\u00e0")
        buf.write("\7n\2\2\u00e0\u00e1\7c\2\2\u00e1\u00e2\7t\2\2\u00e2\u00e3")
        buf.write("\7\"\2\2\u00e3\u00e4\7v\2\2\u00e4\u00e6\7q\2\2\u00e5\u00be")
        buf.write("\3\2\2\2\u00e5\u00c9\3\2\2\2\u00e5\u00d3\3\2\2\2\u00e5")
        buf.write("\u00db\3\2\2\2\u00e6\20\3\2\2\2\u00e7\u00e9\t\2\2\2\u00e8")
        buf.write("\u00e7\3\2\2\2\u00e9\u00ea\3\2\2\2\u00ea\u00e8\3\2\2\2")
        buf.write("\u00ea\u00eb\3\2\2\2\u00eb\22\3\2\2\2\u00ec\u00ee\t\2")
        buf.write("\2\2\u00ed\u00ec\3\2\2\2\u00ee\u00ef\3\2\2\2\u00ef\u00ed")
        buf.write("\3\2\2\2\u00ef\u00f0\3\2\2\2\u00f0\24\3\2\2\2\u00f1\u00f2")
        buf.write("\7w\2\2\u00f2\u00f3\7p\2\2\u00f3\u00f4\7k\2\2\u00f4\u00f5")
        buf.write("\7v\2\2\u00f5\u0105\7u\2\2\u00f6\u00f7\7r\2\2\u00f7\u00f8")
        buf.write("\7g\2\2\u00f8\u00f9\7t\2\2\u00f9\u00fa\7e\2\2\u00fa\u00fb")
        buf.write("\7g\2\2\u00fb\u00fc\7p\2\2\u00fc\u0105\7v\2\2\u00fd\u00fe")
        buf.write("\7f\2\2\u00fe\u00ff\7q\2\2\u00ff\u0100\7n\2\2\u0100\u0101")
        buf.write("\7n\2\2\u0101\u0102\7c\2\2\u0102\u0103\7t\2\2\u0103\u0105")
        buf.write("\7u\2\2\u0104\u00f1\3\2\2\2\u0104\u00f6\3\2\2\2\u0104")
        buf.write("\u00fd\3\2\2\2\u0105\26\3\2\2\2\u0106\u0107\t\3\2\2\u0107")
        buf.write("\30\3\2\2\2\u0108\u010a\t\4\2\2\u0109\u0108\3\2\2\2\u010a")
        buf.write("\u010b\3\2\2\2\u010b\u0109\3\2\2\2\u010b\u010c\3\2\2\2")
        buf.write("\u010c\32\3\2\2\2\u010d\u010f\t\5\2\2\u010e\u010d\3\2")
        buf.write("\2\2\u010f\u0110\3\2\2\2\u0110\u010e\3\2\2\2\u0110\u0111")
        buf.write("\3\2\2\2\u0111\u0112\3\2\2\2\u0112\u0113\b\16\2\2\u0113")
        buf.write("\34\3\2\2\2\r\2Ib\u008d\u00bc\u00e5\u00ea\u00ef\u0104")
        buf.write("\u010b\u0110\3\2\3\2")
        return buf.getvalue()


class IELTSWritingLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    T__0 = 1
    T__1 = 2
    NOUN = 3
    ADJ = 4
    VERB = 5
    ADVERB = 6
    COMPARE = 7
    YEAR = 8
    NUMBER = 9
    UNIT = 10
    PUNCT = 11
    WORD = 12
    WS = 13

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "'in'", "'Overall'" ]

    symbolicNames = [ "<INVALID>",
            "NOUN", "ADJ", "VERB", "ADVERB", "COMPARE", "YEAR", "NUMBER", 
            "UNIT", "PUNCT", "WORD", "WS" ]

    ruleNames = [ "T__0", "T__1", "NOUN", "ADJ", "VERB", "ADVERB", "COMPARE", 
                  "YEAR", "NUMBER", "UNIT", "PUNCT", "WORD", "WS" ]

    grammarFileName = "IELTSWriting.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


