# Generated from IELTSWriting.g4 by ANTLR 4.9.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\17")
        buf.write("W\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b")
        buf.write("\t\b\3\2\6\2\22\n\2\r\2\16\2\23\3\2\3\2\3\3\3\3\3\3\3")
        buf.write("\3\3\3\5\3\35\n\3\3\4\3\4\3\4\5\4\"\n\4\3\4\3\4\5\4&\n")
        buf.write("\4\3\4\3\4\3\5\3\5\3\5\5\5-\n\5\3\5\3\5\3\5\3\5\5\5\63")
        buf.write("\n\5\3\5\3\5\3\6\3\6\3\6\5\6:\n\6\3\6\3\6\3\6\3\6\7\6")
        buf.write("@\n\6\f\6\16\6C\13\6\3\6\3\6\3\7\3\7\7\7I\n\7\f\7\16\7")
        buf.write("L\13\7\3\7\3\7\3\b\6\bQ\n\b\r\b\16\bR\3\b\3\b\3\b\2\2")
        buf.write("\t\2\4\6\b\n\f\16\2\4\4\2\f\f\16\16\4\2\5\6\16\16\2\\")
        buf.write("\2\21\3\2\2\2\4\34\3\2\2\2\6!\3\2\2\2\b,\3\2\2\2\n9\3")
        buf.write("\2\2\2\fF\3\2\2\2\16P\3\2\2\2\20\22\5\4\3\2\21\20\3\2")
        buf.write("\2\2\22\23\3\2\2\2\23\21\3\2\2\2\23\24\3\2\2\2\24\25\3")
        buf.write("\2\2\2\25\26\7\2\2\3\26\3\3\2\2\2\27\35\5\6\4\2\30\35")
        buf.write("\5\b\5\2\31\35\5\n\6\2\32\35\5\f\7\2\33\35\5\16\b\2\34")
        buf.write("\27\3\2\2\2\34\30\3\2\2\2\34\31\3\2\2\2\34\32\3\2\2\2")
        buf.write("\34\33\3\2\2\2\35\5\3\2\2\2\36\"\7\5\2\2\37 \7\6\2\2 ")
        buf.write("\"\7\5\2\2!\36\3\2\2\2!\37\3\2\2\2\"#\3\2\2\2#%\7\7\2")
        buf.write("\2$&\7\b\2\2%$\3\2\2\2%&\3\2\2\2&\'\3\2\2\2\'(\7\r\2\2")
        buf.write("(\7\3\2\2\2)-\7\5\2\2*+\7\6\2\2+-\7\5\2\2,)\3\2\2\2,*")
        buf.write("\3\2\2\2-.\3\2\2\2.\62\7\t\2\2/\63\7\5\2\2\60\61\7\6\2")
        buf.write("\2\61\63\7\5\2\2\62/\3\2\2\2\62\60\3\2\2\2\63\64\3\2\2")
        buf.write("\2\64\65\7\r\2\2\65\t\3\2\2\2\66:\7\5\2\2\678\7\6\2\2")
        buf.write("8:\7\5\2\29\66\3\2\2\29\67\3\2\2\2:;\3\2\2\2;<\7\3\2\2")
        buf.write("<=\7\n\2\2=A\7\13\2\2>@\t\2\2\2?>\3\2\2\2@C\3\2\2\2A?")
        buf.write("\3\2\2\2AB\3\2\2\2BD\3\2\2\2CA\3\2\2\2DE\7\r\2\2E\13\3")
        buf.write("\2\2\2FJ\7\4\2\2GI\t\3\2\2HG\3\2\2\2IL\3\2\2\2JH\3\2\2")
        buf.write("\2JK\3\2\2\2KM\3\2\2\2LJ\3\2\2\2MN\7\r\2\2N\r\3\2\2\2")
        buf.write("OQ\t\3\2\2PO\3\2\2\2QR\3\2\2\2RP\3\2\2\2RS\3\2\2\2ST\3")
        buf.write("\2\2\2TU\7\r\2\2U\17\3\2\2\2\f\23\34!%,\629AJR")
        return buf.getvalue()


class IELTSWritingParser ( Parser ):

    grammarFileName = "IELTSWriting.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'in'", "'Overall'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "NOUN", "ADJ", 
                      "VERB", "ADVERB", "COMPARE", "YEAR", "NUMBER", "UNIT", 
                      "PUNCT", "WORD", "WS" ]

    RULE_essay = 0
    RULE_sentence = 1
    RULE_trend = 2
    RULE_comparison = 3
    RULE_data = 4
    RULE_overview = 5
    RULE_other = 6

    ruleNames =  [ "essay", "sentence", "trend", "comparison", "data", "overview", 
                   "other" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    NOUN=3
    ADJ=4
    VERB=5
    ADVERB=6
    COMPARE=7
    YEAR=8
    NUMBER=9
    UNIT=10
    PUNCT=11
    WORD=12
    WS=13

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class EssayContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(IELTSWritingParser.EOF, 0)

        def sentence(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(IELTSWritingParser.SentenceContext)
            else:
                return self.getTypedRuleContext(IELTSWritingParser.SentenceContext,i)


        def getRuleIndex(self):
            return IELTSWritingParser.RULE_essay

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEssay" ):
                listener.enterEssay(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEssay" ):
                listener.exitEssay(self)




    def essay(self):

        localctx = IELTSWritingParser.EssayContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_essay)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 15 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 14
                self.sentence()
                self.state = 17 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << IELTSWritingParser.T__1) | (1 << IELTSWritingParser.NOUN) | (1 << IELTSWritingParser.ADJ) | (1 << IELTSWritingParser.WORD))) != 0)):
                    break

            self.state = 19
            self.match(IELTSWritingParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SentenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def trend(self):
            return self.getTypedRuleContext(IELTSWritingParser.TrendContext,0)


        def comparison(self):
            return self.getTypedRuleContext(IELTSWritingParser.ComparisonContext,0)


        def data(self):
            return self.getTypedRuleContext(IELTSWritingParser.DataContext,0)


        def overview(self):
            return self.getTypedRuleContext(IELTSWritingParser.OverviewContext,0)


        def other(self):
            return self.getTypedRuleContext(IELTSWritingParser.OtherContext,0)


        def getRuleIndex(self):
            return IELTSWritingParser.RULE_sentence

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentence" ):
                listener.enterSentence(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentence" ):
                listener.exitSentence(self)




    def sentence(self):

        localctx = IELTSWritingParser.SentenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_sentence)
        try:
            self.state = 26
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 21
                self.trend()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 22
                self.comparison()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 23
                self.data()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 24
                self.overview()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 25
                self.other()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TrendContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VERB(self):
            return self.getToken(IELTSWritingParser.VERB, 0)

        def PUNCT(self):
            return self.getToken(IELTSWritingParser.PUNCT, 0)

        def NOUN(self):
            return self.getToken(IELTSWritingParser.NOUN, 0)

        def ADJ(self):
            return self.getToken(IELTSWritingParser.ADJ, 0)

        def ADVERB(self):
            return self.getToken(IELTSWritingParser.ADVERB, 0)

        def getRuleIndex(self):
            return IELTSWritingParser.RULE_trend

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTrend" ):
                listener.enterTrend(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTrend" ):
                listener.exitTrend(self)




    def trend(self):

        localctx = IELTSWritingParser.TrendContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_trend)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 31
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [IELTSWritingParser.NOUN]:
                self.state = 28
                self.match(IELTSWritingParser.NOUN)
                pass
            elif token in [IELTSWritingParser.ADJ]:
                self.state = 29
                self.match(IELTSWritingParser.ADJ)
                self.state = 30
                self.match(IELTSWritingParser.NOUN)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 33
            self.match(IELTSWritingParser.VERB)
            self.state = 35
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==IELTSWritingParser.ADVERB:
                self.state = 34
                self.match(IELTSWritingParser.ADVERB)


            self.state = 37
            self.match(IELTSWritingParser.PUNCT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ComparisonContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMPARE(self):
            return self.getToken(IELTSWritingParser.COMPARE, 0)

        def PUNCT(self):
            return self.getToken(IELTSWritingParser.PUNCT, 0)

        def NOUN(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.NOUN)
            else:
                return self.getToken(IELTSWritingParser.NOUN, i)

        def ADJ(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.ADJ)
            else:
                return self.getToken(IELTSWritingParser.ADJ, i)

        def getRuleIndex(self):
            return IELTSWritingParser.RULE_comparison

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComparison" ):
                listener.enterComparison(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComparison" ):
                listener.exitComparison(self)




    def comparison(self):

        localctx = IELTSWritingParser.ComparisonContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_comparison)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 42
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [IELTSWritingParser.NOUN]:
                self.state = 39
                self.match(IELTSWritingParser.NOUN)
                pass
            elif token in [IELTSWritingParser.ADJ]:
                self.state = 40
                self.match(IELTSWritingParser.ADJ)
                self.state = 41
                self.match(IELTSWritingParser.NOUN)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 44
            self.match(IELTSWritingParser.COMPARE)
            self.state = 48
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [IELTSWritingParser.NOUN]:
                self.state = 45
                self.match(IELTSWritingParser.NOUN)
                pass
            elif token in [IELTSWritingParser.ADJ]:
                self.state = 46
                self.match(IELTSWritingParser.ADJ)
                self.state = 47
                self.match(IELTSWritingParser.NOUN)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 50
            self.match(IELTSWritingParser.PUNCT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DataContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def YEAR(self):
            return self.getToken(IELTSWritingParser.YEAR, 0)

        def NUMBER(self):
            return self.getToken(IELTSWritingParser.NUMBER, 0)

        def PUNCT(self):
            return self.getToken(IELTSWritingParser.PUNCT, 0)

        def NOUN(self):
            return self.getToken(IELTSWritingParser.NOUN, 0)

        def ADJ(self):
            return self.getToken(IELTSWritingParser.ADJ, 0)

        def UNIT(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.UNIT)
            else:
                return self.getToken(IELTSWritingParser.UNIT, i)

        def WORD(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.WORD)
            else:
                return self.getToken(IELTSWritingParser.WORD, i)

        def getRuleIndex(self):
            return IELTSWritingParser.RULE_data

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterData" ):
                listener.enterData(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitData" ):
                listener.exitData(self)




    def data(self):

        localctx = IELTSWritingParser.DataContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_data)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 55
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [IELTSWritingParser.NOUN]:
                self.state = 52
                self.match(IELTSWritingParser.NOUN)
                pass
            elif token in [IELTSWritingParser.ADJ]:
                self.state = 53
                self.match(IELTSWritingParser.ADJ)
                self.state = 54
                self.match(IELTSWritingParser.NOUN)
                pass
            else:
                raise NoViableAltException(self)

            self.state = 57
            self.match(IELTSWritingParser.T__0)
            self.state = 58
            self.match(IELTSWritingParser.YEAR)
            self.state = 59
            self.match(IELTSWritingParser.NUMBER)
            self.state = 63
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==IELTSWritingParser.UNIT or _la==IELTSWritingParser.WORD:
                self.state = 60
                _la = self._input.LA(1)
                if not(_la==IELTSWritingParser.UNIT or _la==IELTSWritingParser.WORD):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 65
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 66
            self.match(IELTSWritingParser.PUNCT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OverviewContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PUNCT(self):
            return self.getToken(IELTSWritingParser.PUNCT, 0)

        def WORD(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.WORD)
            else:
                return self.getToken(IELTSWritingParser.WORD, i)

        def NOUN(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.NOUN)
            else:
                return self.getToken(IELTSWritingParser.NOUN, i)

        def ADJ(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.ADJ)
            else:
                return self.getToken(IELTSWritingParser.ADJ, i)

        def getRuleIndex(self):
            return IELTSWritingParser.RULE_overview

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOverview" ):
                listener.enterOverview(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOverview" ):
                listener.exitOverview(self)




    def overview(self):

        localctx = IELTSWritingParser.OverviewContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_overview)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 68
            self.match(IELTSWritingParser.T__1)
            self.state = 72
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << IELTSWritingParser.NOUN) | (1 << IELTSWritingParser.ADJ) | (1 << IELTSWritingParser.WORD))) != 0):
                self.state = 69
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << IELTSWritingParser.NOUN) | (1 << IELTSWritingParser.ADJ) | (1 << IELTSWritingParser.WORD))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 74
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 75
            self.match(IELTSWritingParser.PUNCT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class OtherContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PUNCT(self):
            return self.getToken(IELTSWritingParser.PUNCT, 0)

        def WORD(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.WORD)
            else:
                return self.getToken(IELTSWritingParser.WORD, i)

        def NOUN(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.NOUN)
            else:
                return self.getToken(IELTSWritingParser.NOUN, i)

        def ADJ(self, i:int=None):
            if i is None:
                return self.getTokens(IELTSWritingParser.ADJ)
            else:
                return self.getToken(IELTSWritingParser.ADJ, i)

        def getRuleIndex(self):
            return IELTSWritingParser.RULE_other

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterOther" ):
                listener.enterOther(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitOther" ):
                listener.exitOther(self)




    def other(self):

        localctx = IELTSWritingParser.OtherContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_other)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 78 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 77
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << IELTSWritingParser.NOUN) | (1 << IELTSWritingParser.ADJ) | (1 << IELTSWritingParser.WORD))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 80 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << IELTSWritingParser.NOUN) | (1 << IELTSWritingParser.ADJ) | (1 << IELTSWritingParser.WORD))) != 0)):
                    break

            self.state = 82
            self.match(IELTSWritingParser.PUNCT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





