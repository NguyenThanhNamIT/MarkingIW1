// Generated from f:/MarkingIW1-main/MarkingIW1-main/src/IELTSWriting.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class IELTSWritingParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, NOUN=3, ADJ=4, VERB=5, ADVERB=6, COMPARE=7, YEAR=8, NUMBER=9, 
		UNIT=10, PUNCT=11, WORD=12, WS=13;
	public static final int
		RULE_essay = 0, RULE_sentence = 1, RULE_trend = 2, RULE_comparison = 3, 
		RULE_data = 4, RULE_overview = 5, RULE_other = 6;
	private static String[] makeRuleNames() {
		return new String[] {
			"essay", "sentence", "trend", "comparison", "data", "overview", "other"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'in'", "'Overall'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, "NOUN", "ADJ", "VERB", "ADVERB", "COMPARE", "YEAR", 
			"NUMBER", "UNIT", "PUNCT", "WORD", "WS"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "IELTSWriting.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public IELTSWritingParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class EssayContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(IELTSWritingParser.EOF, 0); }
		public List<SentenceContext> sentence() {
			return getRuleContexts(SentenceContext.class);
		}
		public SentenceContext sentence(int i) {
			return getRuleContext(SentenceContext.class,i);
		}
		public EssayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_essay; }
	}

	public final EssayContext essay() throws RecognitionException {
		EssayContext _localctx = new EssayContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_essay);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(15); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(14);
				sentence();
				}
				}
				setState(17); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 4124L) != 0) );
			setState(19);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class SentenceContext extends ParserRuleContext {
		public TrendContext trend() {
			return getRuleContext(TrendContext.class,0);
		}
		public ComparisonContext comparison() {
			return getRuleContext(ComparisonContext.class,0);
		}
		public DataContext data() {
			return getRuleContext(DataContext.class,0);
		}
		public OverviewContext overview() {
			return getRuleContext(OverviewContext.class,0);
		}
		public OtherContext other() {
			return getRuleContext(OtherContext.class,0);
		}
		public SentenceContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sentence; }
	}

	public final SentenceContext sentence() throws RecognitionException {
		SentenceContext _localctx = new SentenceContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_sentence);
		try {
			setState(26);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(21);
				trend();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(22);
				comparison();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(23);
				data();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(24);
				overview();
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				setState(25);
				other();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class TrendContext extends ParserRuleContext {
		public TerminalNode VERB() { return getToken(IELTSWritingParser.VERB, 0); }
		public TerminalNode PUNCT() { return getToken(IELTSWritingParser.PUNCT, 0); }
		public TerminalNode NOUN() { return getToken(IELTSWritingParser.NOUN, 0); }
		public TerminalNode ADJ() { return getToken(IELTSWritingParser.ADJ, 0); }
		public TerminalNode ADVERB() { return getToken(IELTSWritingParser.ADVERB, 0); }
		public TrendContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_trend; }
	}

	public final TrendContext trend() throws RecognitionException {
		TrendContext _localctx = new TrendContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_trend);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(31);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOUN:
				{
				setState(28);
				match(NOUN);
				}
				break;
			case ADJ:
				{
				setState(29);
				match(ADJ);
				setState(30);
				match(NOUN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(33);
			match(VERB);
			setState(35);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ADVERB) {
				{
				setState(34);
				match(ADVERB);
				}
			}

			setState(37);
			match(PUNCT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ComparisonContext extends ParserRuleContext {
		public TerminalNode COMPARE() { return getToken(IELTSWritingParser.COMPARE, 0); }
		public TerminalNode PUNCT() { return getToken(IELTSWritingParser.PUNCT, 0); }
		public List<TerminalNode> NOUN() { return getTokens(IELTSWritingParser.NOUN); }
		public TerminalNode NOUN(int i) {
			return getToken(IELTSWritingParser.NOUN, i);
		}
		public List<TerminalNode> ADJ() { return getTokens(IELTSWritingParser.ADJ); }
		public TerminalNode ADJ(int i) {
			return getToken(IELTSWritingParser.ADJ, i);
		}
		public ComparisonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_comparison; }
	}

	public final ComparisonContext comparison() throws RecognitionException {
		ComparisonContext _localctx = new ComparisonContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_comparison);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(42);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOUN:
				{
				setState(39);
				match(NOUN);
				}
				break;
			case ADJ:
				{
				setState(40);
				match(ADJ);
				setState(41);
				match(NOUN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(44);
			match(COMPARE);
			setState(48);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOUN:
				{
				setState(45);
				match(NOUN);
				}
				break;
			case ADJ:
				{
				setState(46);
				match(ADJ);
				setState(47);
				match(NOUN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(50);
			match(PUNCT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class DataContext extends ParserRuleContext {
		public TerminalNode YEAR() { return getToken(IELTSWritingParser.YEAR, 0); }
		public TerminalNode NUMBER() { return getToken(IELTSWritingParser.NUMBER, 0); }
		public TerminalNode PUNCT() { return getToken(IELTSWritingParser.PUNCT, 0); }
		public TerminalNode NOUN() { return getToken(IELTSWritingParser.NOUN, 0); }
		public TerminalNode ADJ() { return getToken(IELTSWritingParser.ADJ, 0); }
		public List<TerminalNode> UNIT() { return getTokens(IELTSWritingParser.UNIT); }
		public TerminalNode UNIT(int i) {
			return getToken(IELTSWritingParser.UNIT, i);
		}
		public List<TerminalNode> WORD() { return getTokens(IELTSWritingParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(IELTSWritingParser.WORD, i);
		}
		public DataContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_data; }
	}

	public final DataContext data() throws RecognitionException {
		DataContext _localctx = new DataContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_data);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case NOUN:
				{
				setState(52);
				match(NOUN);
				}
				break;
			case ADJ:
				{
				setState(53);
				match(ADJ);
				setState(54);
				match(NOUN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			setState(57);
			match(T__0);
			setState(58);
			match(YEAR);
			setState(59);
			match(NUMBER);
			setState(63);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==UNIT || _la==WORD) {
				{
				{
				setState(60);
				_la = _input.LA(1);
				if ( !(_la==UNIT || _la==WORD) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(65);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(66);
			match(PUNCT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OverviewContext extends ParserRuleContext {
		public TerminalNode PUNCT() { return getToken(IELTSWritingParser.PUNCT, 0); }
		public List<TerminalNode> WORD() { return getTokens(IELTSWritingParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(IELTSWritingParser.WORD, i);
		}
		public List<TerminalNode> NOUN() { return getTokens(IELTSWritingParser.NOUN); }
		public TerminalNode NOUN(int i) {
			return getToken(IELTSWritingParser.NOUN, i);
		}
		public List<TerminalNode> ADJ() { return getTokens(IELTSWritingParser.ADJ); }
		public TerminalNode ADJ(int i) {
			return getToken(IELTSWritingParser.ADJ, i);
		}
		public OverviewContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_overview; }
	}

	public final OverviewContext overview() throws RecognitionException {
		OverviewContext _localctx = new OverviewContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_overview);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(68);
			match(T__1);
			setState(72);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & 4120L) != 0)) {
				{
				{
				setState(69);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 4120L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(74);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(75);
			match(PUNCT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class OtherContext extends ParserRuleContext {
		public TerminalNode PUNCT() { return getToken(IELTSWritingParser.PUNCT, 0); }
		public List<TerminalNode> WORD() { return getTokens(IELTSWritingParser.WORD); }
		public TerminalNode WORD(int i) {
			return getToken(IELTSWritingParser.WORD, i);
		}
		public List<TerminalNode> NOUN() { return getTokens(IELTSWritingParser.NOUN); }
		public TerminalNode NOUN(int i) {
			return getToken(IELTSWritingParser.NOUN, i);
		}
		public List<TerminalNode> ADJ() { return getTokens(IELTSWritingParser.ADJ); }
		public TerminalNode ADJ(int i) {
			return getToken(IELTSWritingParser.ADJ, i);
		}
		public OtherContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_other; }
	}

	public final OtherContext other() throws RecognitionException {
		OtherContext _localctx = new OtherContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_other);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(78); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(77);
				_la = _input.LA(1);
				if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 4120L) != 0)) ) {
				_errHandler.recoverInline(this);
				}
				else {
					if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
					_errHandler.reportMatch(this);
					consume();
				}
				}
				}
				setState(80); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 4120L) != 0) );
			setState(82);
			match(PUNCT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\u0004\u0001\rU\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0001\u0000\u0004\u0000\u0010"+
		"\b\u0000\u000b\u0000\f\u0000\u0011\u0001\u0000\u0001\u0000\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u0001\u001b\b\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0003\u0002 \b\u0002\u0001\u0002"+
		"\u0001\u0002\u0003\u0002$\b\u0002\u0001\u0002\u0001\u0002\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0003\u0003+\b\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0003\u0001\u0003\u0003\u00031\b\u0003\u0001\u0003\u0001\u0003"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0003\u00048\b\u0004\u0001\u0004"+
		"\u0001\u0004\u0001\u0004\u0001\u0004\u0005\u0004>\b\u0004\n\u0004\f\u0004"+
		"A\t\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001\u0005\u0005\u0005"+
		"G\b\u0005\n\u0005\f\u0005J\t\u0005\u0001\u0005\u0001\u0005\u0001\u0006"+
		"\u0004\u0006O\b\u0006\u000b\u0006\f\u0006P\u0001\u0006\u0001\u0006\u0001"+
		"\u0006\u0000\u0000\u0007\u0000\u0002\u0004\u0006\b\n\f\u0000\u0002\u0002"+
		"\u0000\n\n\f\f\u0002\u0000\u0003\u0004\f\fZ\u0000\u000f\u0001\u0000\u0000"+
		"\u0000\u0002\u001a\u0001\u0000\u0000\u0000\u0004\u001f\u0001\u0000\u0000"+
		"\u0000\u0006*\u0001\u0000\u0000\u0000\b7\u0001\u0000\u0000\u0000\nD\u0001"+
		"\u0000\u0000\u0000\fN\u0001\u0000\u0000\u0000\u000e\u0010\u0003\u0002"+
		"\u0001\u0000\u000f\u000e\u0001\u0000\u0000\u0000\u0010\u0011\u0001\u0000"+
		"\u0000\u0000\u0011\u000f\u0001\u0000\u0000\u0000\u0011\u0012\u0001\u0000"+
		"\u0000\u0000\u0012\u0013\u0001\u0000\u0000\u0000\u0013\u0014\u0005\u0000"+
		"\u0000\u0001\u0014\u0001\u0001\u0000\u0000\u0000\u0015\u001b\u0003\u0004"+
		"\u0002\u0000\u0016\u001b\u0003\u0006\u0003\u0000\u0017\u001b\u0003\b\u0004"+
		"\u0000\u0018\u001b\u0003\n\u0005\u0000\u0019\u001b\u0003\f\u0006\u0000"+
		"\u001a\u0015\u0001\u0000\u0000\u0000\u001a\u0016\u0001\u0000\u0000\u0000"+
		"\u001a\u0017\u0001\u0000\u0000\u0000\u001a\u0018\u0001\u0000\u0000\u0000"+
		"\u001a\u0019\u0001\u0000\u0000\u0000\u001b\u0003\u0001\u0000\u0000\u0000"+
		"\u001c \u0005\u0003\u0000\u0000\u001d\u001e\u0005\u0004\u0000\u0000\u001e"+
		" \u0005\u0003\u0000\u0000\u001f\u001c\u0001\u0000\u0000\u0000\u001f\u001d"+
		"\u0001\u0000\u0000\u0000 !\u0001\u0000\u0000\u0000!#\u0005\u0005\u0000"+
		"\u0000\"$\u0005\u0006\u0000\u0000#\"\u0001\u0000\u0000\u0000#$\u0001\u0000"+
		"\u0000\u0000$%\u0001\u0000\u0000\u0000%&\u0005\u000b\u0000\u0000&\u0005"+
		"\u0001\u0000\u0000\u0000\'+\u0005\u0003\u0000\u0000()\u0005\u0004\u0000"+
		"\u0000)+\u0005\u0003\u0000\u0000*\'\u0001\u0000\u0000\u0000*(\u0001\u0000"+
		"\u0000\u0000+,\u0001\u0000\u0000\u0000,0\u0005\u0007\u0000\u0000-1\u0005"+
		"\u0003\u0000\u0000./\u0005\u0004\u0000\u0000/1\u0005\u0003\u0000\u0000"+
		"0-\u0001\u0000\u0000\u00000.\u0001\u0000\u0000\u000012\u0001\u0000\u0000"+
		"\u000023\u0005\u000b\u0000\u00003\u0007\u0001\u0000\u0000\u000048\u0005"+
		"\u0003\u0000\u000056\u0005\u0004\u0000\u000068\u0005\u0003\u0000\u0000"+
		"74\u0001\u0000\u0000\u000075\u0001\u0000\u0000\u000089\u0001\u0000\u0000"+
		"\u00009:\u0005\u0001\u0000\u0000:;\u0005\b\u0000\u0000;?\u0005\t\u0000"+
		"\u0000<>\u0007\u0000\u0000\u0000=<\u0001\u0000\u0000\u0000>A\u0001\u0000"+
		"\u0000\u0000?=\u0001\u0000\u0000\u0000?@\u0001\u0000\u0000\u0000@B\u0001"+
		"\u0000\u0000\u0000A?\u0001\u0000\u0000\u0000BC\u0005\u000b\u0000\u0000"+
		"C\t\u0001\u0000\u0000\u0000DH\u0005\u0002\u0000\u0000EG\u0007\u0001\u0000"+
		"\u0000FE\u0001\u0000\u0000\u0000GJ\u0001\u0000\u0000\u0000HF\u0001\u0000"+
		"\u0000\u0000HI\u0001\u0000\u0000\u0000IK\u0001\u0000\u0000\u0000JH\u0001"+
		"\u0000\u0000\u0000KL\u0005\u000b\u0000\u0000L\u000b\u0001\u0000\u0000"+
		"\u0000MO\u0007\u0001\u0000\u0000NM\u0001\u0000\u0000\u0000OP\u0001\u0000"+
		"\u0000\u0000PN\u0001\u0000\u0000\u0000PQ\u0001\u0000\u0000\u0000QR\u0001"+
		"\u0000\u0000\u0000RS\u0005\u000b\u0000\u0000S\r\u0001\u0000\u0000\u0000"+
		"\n\u0011\u001a\u001f#*07?HP";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}